import React from 'react'
import './sechm.css'
import '../../../node_modules/bootstrap/dist/css/bootstrap.min.css';

export const Sechm = () => {
    return (
        <>
            <div className='container-fulid mx-5'>
                <div className='row'>
                    <div className='secondhome'>
                        <div className='secondimage' style={{ height: "80vh" }}>
                            <div className='secondcontent'>
                                <h4>Subscribe Now For Get Every Day Tips</h4>
                                <p>A wonderful serenity has taken possession far away,behind the wprd moyuntains</p>
                                <div className='btnin' style={{ display: "flex", border: "1px solid white" }}>
                                    <input type="text" className='inputi' placeholder="  enter your Email" />
                                    <button className='btni' id="clear">Submit</button>
                                </div>                  
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </>
    )
}
